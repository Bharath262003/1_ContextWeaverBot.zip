from flask import Flask, render_template, request, jsonify
import sqlite3
from datetime import datetime
import random

app = Flask(__name__)

DATABASE = "conversation_store.db"

def init_db():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS chats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_msg TEXT,
            bot_reply TEXT,
            timestamp TEXT
        )
    """)
    conn.commit()
    conn.close()

init_db()

def get_previous_message():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT user_msg FROM chats ORDER BY id DESC LIMIT 1")
    last = cursor.fetchone()
    conn.close()
    return last[0] if last else None

def generate_reply(user_input):
    user_input_lower = user_input.lower()
    previous = get_previous_message()

    greetings = [
        "Hello 👋 I'm ContextWeaverBot! How are you today?",
        "Hi there! 😊 What would you like to talk about?",
        "Hey! I'm here and ready to chat."
    ]

    fine_responses = [
        "That's great to hear! What’s on your mind?",
        "Nice 😊 Tell me more!",
        "Awesome! How can I assist you today?"
    ]

    jokes = [
        "Why did the computer go to therapy? It had too many bytes of emotional baggage! 😄",
        "Why do programmers prefer dark mode? Because light attracts bugs!",
        "Why was the computer cold? It forgot to close its Windows!"
    ]

    if "hello" in user_input_lower or "hi" in user_input_lower:
        return random.choice(greetings)

    if "how are you" in user_input_lower:
        return "I'm doing fantastic! Thanks for asking 😊 How about you?"

    if "fine" in user_input_lower or "good" in user_input_lower:
        return random.choice(fine_responses)

    if "your name" in user_input_lower:
        return "I am ContextWeaverBot, your AI assistant with contextual memory."

    if "who created you" in user_input_lower or "developer" in user_input_lower:
        return "I was developed as an academic AI project to demonstrate contextual conversation."

    if "what can you do" in user_input_lower:
        return "I can chat with you, remember previous messages, tell time and date, and respond based on simple conversational logic."

    if "previous" in user_input_lower and previous:
        return f"You previously said: '{previous}'"

    if "time" in user_input_lower:
        return f"The current time is {datetime.now().strftime('%H:%M:%S')}"

    if "date" in user_input_lower:
        return f"Today's date is {datetime.now().strftime('%Y-%m-%d')}"

    if "thank" in user_input_lower:
        return "You're welcome! I'm always happy to help."

    if "bye" in user_input_lower or "goodbye" in user_input_lower:
        return "Goodbye 👋 Have a wonderful day ahead!"

    if "help" in user_input_lower:
        return "You can greet me, ask about time or date, request a joke, or ask about your previous message."

    if "weather" in user_input_lower:
        return "I cannot access live weather updates right now, but I hope it's a beautiful day where you are!"

    if "joke" in user_input_lower:
        return random.choice(jokes)

    if "ai" in user_input_lower:
        return "AI stands for Artificial Intelligence. It allows machines to simulate human intelligence."

    if "python" in user_input_lower:
        return "Python is a powerful and easy-to-learn programming language widely used in AI and web development."

    return f"You said: '{user_input}'. That sounds interesting! Tell me more."

@app.route("/")
def home():
    return render_template("chat_ui.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_input = data["message"]
    bot_reply = generate_reply(user_input)

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO chats (user_msg, bot_reply, timestamp) VALUES (?, ?, ?)",
        (user_input, bot_reply, datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    )
    conn.commit()
    conn.close()

    return jsonify({"reply": bot_reply})

if __name__ == "__main__":
    app.run(debug=True)
